CREATE TABLE friends (
  friend_id INT PRIMARY KEY,
  character_name VARCHAR(100),
  movie_name VARCHAR(100),
  year_produced INT
);

INSERT INTO friends (friend_id, character_name, movie_name, year_produced)
VALUES
(1, 'Peter Parker', 'Spider-Man: Homecoming', 2017),
(2, 'Miles Morales', 'Spider-Man: Into the Spider-Verse', 2018),
(3, 'Gwen Stacy', 'Spider-Man: The Amazing spider-man', 2012),
(4, 'Mary Jane Watson', 'Spider-man', 2002);

SELECT*
FROM friends
WHERE year_produced = (
  SELECT MAX(year_produced)
  FROM friends
  WHERE movie_name LIKE '%Spider-Man%'
);
--this database was created by Emmanuel